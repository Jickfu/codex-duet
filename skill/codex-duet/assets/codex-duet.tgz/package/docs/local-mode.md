# LOCAL mode

M5 extension: an explicitly authorized, unsent CODEX_BROWSER Reviewer can move to a known stable conversation using `local reviewer-handoff --task <id> --from <url> --to <url> --reason <text>`. The command preserves the exact control and lifecycle, records both bindings before switching, and never sends. An interrupted handoff must be recovered with identical arguments before ordinary Browser operations continue. See [ADR-028](adr/ADR-028-local-reviewer-conversation-handoff.md) for eligibility and bootstrap boundaries.

Status: **M4 FROZEN — LOCALLY TESTABLE SCOPE; M5 FROZEN — SINGLE-USER REMOTE DEVELOPMENT SCOPE**. See the [freeze and acceptance record](milestones/M4-local-readonly-mcp.md) and [M5 remote setup](remote-local-mode.md).

LOCAL mode is for private, unpushed, or uncommitted Git workspaces. It preserves Codex as the sole Executor. Immutable snapshots, bounded snapshot-bound reads, a loopback MCP server library, capability-scoped response ingress, guarded lifecycle, both selected Browser providers and optional Discussion are implemented. M4 acceptance is local/fixture-based. The separate M5 development entry point is `local remote-serve`; a [generated-task real ChatGPT loop](milestones/M5-live-acceptance-2026-09-04.md) reached DONE with bounded format repair and an authorized conversation handoff. The remaining sections describe the frozen M4 foundation unless noted otherwise.

## Implemented data-plane CLI

Run at a Git worktree root with an existing HEAD. No remote is required; pre-existing dirty files are permitted. These commands create task-scoped metadata under `.chatbridge`, but never commit, push, execute tests, send messages or approve review results. `duet` remains the existing GITHUB lifecycle entry point; these commands do not substitute for a LOCAL PLAN/Discussion/execution gate.

```text
chatbridge local init-task --task demo
chatbridge local assert-ready --task demo
chatbridge local capture --task demo
chatbridge local record-evidence --task demo --evidence-file .chatbridge/evidence-input.json
chatbridge local prepare-review --task demo --iteration 1
chatbridge local status --task demo
```

Initialize before editing to preserve the baseline. After authorized edits, capture a candidate, run tests yourself against that candidate, then supply its exact snapshot identity in the evidence file. Keep the input file under `.chatbridge` or outside the workspace so creating it does not change the review surface. `record-evidence` verifies live state still matches the named snapshot; it records the caller's assertion, not independent proof that tests ran.

The evidence file is a strict JSON object with `tests` and `execution` fields. Both contain `version: 1`, `taskId`, positive `iteration`, exact `snapshotId`, and a `summary` string. `tests` additionally requires `status` (`PASS`, `FAIL`, or `NOT_RUN`) and `recordedAt` (ISO timestamp). Preserve the complete original input for immutable replay; changing its timestamp or summary is not an identical retry.

`prepare-review` requires matching durable evidence and returns a `LocalReviewTargetV1`, never a GitHub `REVIEW_REF`. The current prepared iteration replays its immutable target even after live edits; `assert-ready` separately rejects live drift. New iterations must be sequential. The drift check is not execution authorization. `init-task` recovers existing context only when live state still matches the baseline or latest review; do not use it to reset a dirty in-progress task.

### Task semantics and control projection

Place both LOCAL contract documents in the workspace before initializing its baseline. Normalize the task into `LocalTaskSpecV1` with the baseline context returned by `init-task`, canonical SHA-256 integrity, and `AT_BASELINE_SNAPSHOT` contract resolution. See [ADR-018](adr/ADR-018-local-task-spec-control.md) for the identity and response rules.

```text
chatbridge local bind-task-spec --task demo --request-file .chatbridge/request.txt --task-spec-file .chatbridge/spec-input.json
chatbridge local project-control --task demo
chatbridge local project-control --task demo --review
```

Bind before editing; the first projection produces Planner control. The `--review` form requires an already-prepared review target. Output is JSON with an `envelope` string, not a send operation. Oversize messages fail without truncation. The guarded lifecycle below owns control messages after run initialization.

After run-init, `project-control` is refused: use the exact `control` from run-status or a lifecycle command, including all accepted user decisions.

Snapshot-bound MCP tools expose allowed repository files read-only. LOCAL has separate Planner/Reviewer contracts resolved at baseline, without changing frozen M3.2c or GITHUB contracts. The [durable lifecycle core](adr/ADR-019-local-lifecycle-core.md) reuses shared transitions and response ingress with separate LOCAL persistence.

### Guarded lifecycle CLI

The [stored gates](adr/ADR-020-local-stored-gates.md) and lifecycle commands support exact CODEX_BROWSER evidence and the additive [LOCAL Playwright proof](adr/ADR-026-local-playwright-proof.md):

```text
chatbridge local run-init --task demo
chatbridge local run-status --task demo
chatbridge local confirm-control --task demo
chatbridge local ingest-response --task demo --message-file .chatbridge/response.txt
chatbridge local begin-execution --task demo
chatbridge local reconcile-execution --task demo
chatbridge local run-prepare-review --task demo
```

Persist an explicit interaction policy using the existing interaction-policy workflow before run-init. Enabled Discussion must already have complete, verified convergence evidence; a manually written CONVERGED summary cannot bypass the Browser artifact check.

Use the [LOCAL Discussion commands](adr/ADR-021-local-discussion-recovery.md) after binding TaskSpec and before run-init:

```text
chatbridge local discussion-prepare --task demo --round 1 --request-file .chatbridge/question.txt
chatbridge local discussion-ingest --task demo --message-file .chatbridge/discussion-response.json
chatbridge local discussion-status --task demo
chatbridge local discussion-recover --task demo
```

Preparation returns `control` and `controlFile`. Send the exact file through the selected Browser workflow, including its terminal newline, and record the received Browser bytes before Discussion ingestion. A next round requires the previous outcome CONTINUE and an explicit next round number; the limit is three. Retrying the same round/question recovers its original control, not a new send. Status is read-only; recover repairs a missing or stale summary only from validated immutable round evidence. BLOCKED and FAILED never auto-continue.

If primary Discussion returns USER_DECISION_REQUIRED, an explicit user clarification may authorize one supplemental segment of at most three rounds:

```text
chatbridge local discussion-resume --task demo --blocked-control-sha256 <exact-outbound-digest> --decision-file .chatbridge/discussion-decision.txt --scope-unchanged
chatbridge local discussion-ingest --task demo --message-file .chatbridge/supplement-response.json --supplement
chatbridge local discussion-prepare --task demo --round 2 --request-file .chatbridge/next-question.txt --supplement
chatbridge local discussion-status --task demo --supplement
chatbridge local discussion-recover --task demo --supplement
```

Resume returns the first supplemental control and its file. The digest names the blocked primary control including its terminal newline. Keep decision files outside the reviewable surface. Original records are preserved; the supplemental segment never restarts automatically and cannot be replaced by another user decision. It must converge before run-init, and its accepted clarification is bound into subsequent Planner/Reviewer controls. Scope changes require a new task. See [ADR-025](adr/ADR-025-local-discussion-supplement.md).

Use the existing Codex Browser interaction commands to prepare, attempt, confirm and receive the exact control/response bytes. `confirm-control` validates that evidence; it does not send. `ingest-response` requires the exact recorded Browser response. After PLAN is accepted, begin-execution records intent; the caller edits and tests, uses capture/record-evidence, then run-prepare-review persists EXECUTED. Confirm and receive the Reviewer exchange before ingesting the result.

`reconcile-execution` observes an EXECUTING run without advancing it: UNCHANGED, WORKTREE_IN_PROGRESS or REVIEW_PREPARED. Snapshot metadata may be stored, but no source edits, tests, new review targets or sends occur. REVIEW_PREPARED also reports live drift; explicitly use run-prepare-review to recover the published target.

`chatbridge local run-cancel --task demo --reason "operator stop"` durably terminates a cancellable run without reverting code or retracting transport operations. Repeating the same reason is idempotent. Historical response replay cannot revive cancellation. See [ADR-022](adr/ADR-022-local-reconciliation-cancellation.md).

For a lifecycle BLOCKED response, obtain the user's in-scope clarification and save its exact text outside the reviewable surface:

```text
chatbridge local resume-blocked --task demo --blocked-control-sha256 <blocked-control-sha256> --decision-file .chatbridge/decision.txt --scope-unchanged
```

This appends a bound decision and returns PLANNING with a new control, not execution permission. Send, confirm and receive through the selected Browser workflow and accept a fresh PLAN before beginning execution. Reviewer blocking at N resumes planning for N+1 against the reviewed snapshot. The original TaskSpec is unchanged; scope or requirement changes require a new task. Exact retries preserve the decision and never consume a later block. See [ADR-023](adr/ADR-023-local-blocked-user-decisions.md). Pre-run Discussion blocking uses the separate discussion-resume command above.

For a task that selected PLAYWRIGHT_CLI, attach the existing Browser runtime, then use these LOCAL-specific commands (not legacy `send --task`):

```text
chatbridge local browser-send --task demo --round 1 --conversation-url https://chatgpt.com/c/REPLACE_WITH_EXPLICIT_CONVERSATION
chatbridge local browser-wait --task demo --timeout 120000
# Ingest the exact persisted response artifact with discussion-ingest.
# After convergence and run-init, send the stored Planner/Reviewer control:
chatbridge local browser-send --task demo
chatbridge local browser-wait --task demo
```

Add `--supplement` with `--round` for the authorized supplementary segment. The first send requires an explicit stable conversation; later sends reuse it. Send output identifies the operation. Exact artifacts are `.chatbridge/runs/<task>/local/playwright/<operationId>/request.txt` and `response.txt`; use the latter as `--message-file` for the appropriate ingress command. `browser-wait` also returns the response in JSON, without ingesting it. `confirm-control` remains required for Planner/Reviewer lifecycle acceptance.

An ATTEMPTED sidecar means a send may have occurred: stop and inspect, never delete/reset the proof or resend automatically. A legacy marker cannot promote it to CONFIRMED. A wait timeout preserves confirmation and permits another bounded wait. A response-before-checkpoint crash recovers the original artifact without another Browser read. No provider fallback occurs.

The default Browser CLI ingress refuses new MCP-source responses. Explicitly enabled loopback servers can use the authenticated [MCP lifecycle adapter](adr/ADR-024-local-mcp-lifecycle-ingress.md): capabilities do not bypass confirmed Browser send, identity, state or live-snapshot guards. Accepted MCP replies leave Browser state truthful; only an exact ACCEPTED receipt permits the next control without inventing a Browser response. Real remote LOCAL Browser E2E remains M5.

### Bounded format repair

Malformed CODEX_BROWSER replies with losslessly identifiable JSON quoting errors, or exact DONE headers/canonical JSON missing only the DONE section line, can use the additive [format-repair flow](adr/ADR-027-local-format-repair.md). It preserves original artifacts and permits at most two separately evidenced corrections. It does not repair replies locally or bypass lifecycle gates. Other malformed or ambiguous replies remain rejected.

### Explicit loopback library composition

M4 exposes a server library, not a server-management daemon or automatic startup. After building, an operator-owned Node entry point can compose the read-only server as follows:

```js
import path from 'node:path';
import { GitLocalSnapshotAuthority } from './dist/local/git-snapshot-authority.js';
import { LocalEvidenceStore } from './dist/local/evidence-store.js';
import { LocalWorkspaceService } from './dist/local/workspace-service.js';
import { LocalMcpServer } from './dist/local/mcp-server.js';

const authority = await GitLocalSnapshotAuthority.open(process.cwd(), 'demo');
const stateRoot = path.join(process.cwd(), '.chatbridge');
const workspace = new LocalWorkspaceService(authority.store, new LocalEvidenceStore(stateRoot));
const server = new LocalMcpServer({ workspace }); // Default: 127.0.0.1, ephemeral port, eight read tools.
const address = await server.start();
// Connect an explicitly authorized local MCP client to address.url.
// Call await server.close() when the operator-owned session ends.
```

The imports above are relative to the repository build output. This does not provision a remote ChatGPT connector. Optional `submitResponse` requires explicit composition of `LocalMcpCapabilityStore` and `LocalMcpLifecycleIngress`; see ADR-024 and the loopback integration tests. Capabilities must be issued for the exact task/iteration/control, delivered only to the authorized caller, and never committed, logged or inserted into Browser control messages. Automatic issuance/distribution and public exposure are not implemented.

## Target architecture

```mermaid
flowchart TB
    subgraph CP[CONTROL PLANE — shared Browser Bridge]
        C[Codex Desktop] -->|compact C2C| B[Browser Bridge]
        B --> W[ChatGPT Web]
    end
    subgraph DP[LOCAL DATA PLANE — LOCAL M4 / REMOTE M5]
        W -->|MCP read tools| H[Public HTTPS MCP endpoint]
        H --> T[cloudflared]
        T --> M[Local Read-Only MCP Bridge]
        M --> L[Local Workspace]
    end
```

The Data Plane will expose private repository files, unpushed commits, an uncommitted working tree, Git diffs, local documentation, test status, and an execution summary without uploading the code to GitHub.

## Review sequence

```mermaid
sequenceDiagram
    participant C as Codex / Skill
    participant B as Browser Bridge
    participant W as ChatGPT Web
    participant M as Local read-only MCP
    C->>C: Edit workspace and run tests
    C->>B: EXECUTED control request
    B->>W: compact C2C
    W->>M: Read files, git diff, and test status
    Note over W,M: No commit, push, or GitHub REVIEW_REF required
    W->>M: submit_response(PLAN / DONE / BLOCKED)
    M-->>C: Durable task event/state
```

LOCAL mode permits review of uncommitted state. Its review identity must not pretend that the observation is a Git commit:

```text
LOCAL Review Snapshot / Fingerprint contract: ADR-017
```

The implemented provider binds each review to explicit immutable snapshots and a review-target fingerprint under [ADR-017](adr/ADR-017-local-review-identity.md). It does not reuse the GITHUB `REVIEW_REF` contract.

## Current and target response paths

The implemented Frozen M1 return path is:

```text
send → deterministic wait → final browser response
```

The explicitly enabled LOCAL return path is implemented locally; its remote delivery remains M5:

```text
ChatGPT
  ↓
submit_response(capabilityId, capability, taskId, iteration, controlSha256, response)
  ↓
Local Bridge durable task event/state
  ↓
Codex Skill
```

This path can avoid Browser response polling after a capability-authenticated acceptance. It does not replace or retroactively change deterministic M1 `send/wait`, and a capability never bypasses exact Browser send confirmation.

## Read-only MCP tools

The implemented server library's workspace read surface is limited to:

```text
workspace_info
list_directory
read_file
search_workspace
git_status
git_diff
test_status
execution_summary
```

The disabled-by-default, capability-scoped control/return tool is:

```text
submit_response
```

`submit_response` may write only `.chatbridge` internal task/run state. It cannot write workspace content. The MCP server must never expose `write_file`, `delete_file`, `exec`, `shell`, `git_commit`, or `git_push`.

## Security requirements

The Local MCP Bridge enforces:

- canonical workspace-root sandboxing
- path-traversal protection
- symlink-escape protection
- sensitive-file deny policy
- request and response size limits
- `taskId` and iteration validation
- state-transition validation
- secret-safe logging

The deny policy must reject `.env`, `*.pem`, `*.key`, SSH credentials, cloud credentials, token files, and password/secret-like files by default. See [Security](security.md).

## cloudflared role

cloudflared is only the planned LOCAL Data Plane transport:

```text
Internet HTTPS endpoint
        ↓
cloudflared tunnel
        ↓
localhost MCP server
```

It maps remote HTTPS to the local MCP service. It is not a browser-control channel, Codex message channel, or Git transport. Its lifecycle and controlled remote exposure belong to M5.
